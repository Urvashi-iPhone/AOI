//
//  ViewController.h
//  UIPageControlDemo
//
//  Created by user on 12/26/14.
//  Copyright (c) 2014 Neuron. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UIScrollViewDelegate>
{
    IBOutlet UIPageControl *pageControl;
    IBOutlet UIScrollView *scrollView;
}

-(IBAction)changePage:(id)sender;
@end

