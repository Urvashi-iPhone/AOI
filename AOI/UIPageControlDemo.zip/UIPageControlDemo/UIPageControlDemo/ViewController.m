//
//  ViewController.m
//  UIPageControlDemo
//
//  Created by user on 12/26/14.
//  Copyright (c) 2014 Neuron. All rights reserved.
//

#import "ViewController.h"


#define SCROLLWIDTH 279

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{

    scrollView.contentSize=CGSizeMake(SCROLLWIDTH*3, scrollView.frame.size.height);
    scrollView.delegate = self;

    for (int i =0; i<3; i++)
    {
        UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(SCROLLWIDTH*i, 0, scrollView.frame.size.width, scrollView.frame.size.height)];
        if (i==0)
        {
            imageView.backgroundColor = [UIColor redColor];

        }
        else if (i==1)
        {
            imageView.backgroundColor = [UIColor greenColor];

        }
        else
        {
            imageView.backgroundColor = [UIColor yellowColor];
        }
        [scrollView addSubview:imageView];
    }
    
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark changePage

-(IBAction)changePage:(id)sender
{
    [scrollView scrollRectToVisible:CGRectMake(SCROLLWIDTH*pageControl.currentPage, scrollView.frame.origin.y, SCROLLWIDTH, scrollView.frame.size.height) animated:YES];
}


- (void)scrollViewDidEndDecelerating:(UIScrollView *)sender {
    
    [self setIndiactorForCurrentPage];
    
}

-(void)setIndiactorForCurrentPage
{
    uint page = scrollView.contentOffset.x / SCROLLWIDTH;
    [pageControl setCurrentPage:page];
    
}


@end
